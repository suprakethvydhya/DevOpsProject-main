const candidates = {
    '1': {
        name: 'Ganesh Pichika',
        resume: './resumes/Ganesh_Resume.docx',
        details: './candidate_details/Ganesh.txt',
        filters: {
            targetApplicationsCount: 5,
            maxPostsToInspect: 30,

            maxExperienceYears: 10,
            enableExperienceFilter: true,

            targetDomains: [
                'IT',
                'Software',
                'Technology',
                'Engineering',
                'Developer',
                'Development',
                'Cloud',
                'DevOps',
                'Backend',
                'Full Stack',
                'Application',
                'Solutions',
                'Java',
                
            ],
            enableDomainFilter: false,

            targetWorkAuth: 'H1B',
            enableWorkAuthFilter: false
        }
    },
    '2': {
        name: 'Vijay Kumar',
        resume: './resumes/Vijay_Resume.pdf',
        details: './candidate_details/Vijay.txt',
        filters: {
            targetApplicationsCount: 5,
            maxPostsToInspect: 30,

            maxExperienceYears: 5,
            enableExperienceFilter: true,

            targetDomains: [
                'Networks',
                'AWS',
                'Azure',
                'Security', 
            ],
            enableDomainFilter: false,

            targetWorkAuth: 'F-1 STEM OPT',
            enableWorkAuthFilter: false
        }
        
    }
};
function selectCandidate() {
    const choice = process.env.CANDIDATE?.trim();

    console.log('choice:', choice);

    const candidate = candidates[choice];

    if (!candidate) {
        throw new Error(
            `Invalid candidate "${choice}". Use CANDIDATE=1 or CANDIDATE=2.`
        );
    }

    console.log(`Using candidate: ${candidate.name}`);

    return candidate;
}
module.exports = { selectCandidate };